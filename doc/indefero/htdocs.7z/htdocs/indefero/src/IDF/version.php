<?php
return array(
    'version'  => '1.2',
    'revision' => '5101ae5f35b2f64404be43654438731845879aaa',
);
