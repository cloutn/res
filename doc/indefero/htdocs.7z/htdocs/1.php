<?
#print("aaabbbccc");
phpinfo();
?>

